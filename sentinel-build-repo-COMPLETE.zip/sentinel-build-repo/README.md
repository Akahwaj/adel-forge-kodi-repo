# 🎯 SENTINEL BUILD Repository

**Professional Kodi Repository with 18 Premium Add-ons**

---

## 📋 What's Included

### Repository & Wizard
- ✅ **Repository Definition** (repository.sentinel.build)
- ✅ **SENTINEL Wizard** - One-click installer for all 18 add-ons
- ✅ **Complete addons.xml** - All add-ons fully documented
- ✅ **MD5 Checksum** - Integrity verification

### 18 Premium Add-ons

**DEBRID PREMIUM (8):**
1. Umbrella
2. Seren
3. SALTS
4. FEN Light
5. FenSkeleton
6. POV
7. The Gears
8. COSMOS

**FREE STREAMING (7):**
9. The Crew
10. Red Light
11. VIDSRC
12. Scrubs V2
13. Gratis Red
14. Diggz Free99
15. Chains

**TORRENT (3):**
16. Elementum
17. Jacktook
18. MediaFusion

---

## 🚀 Installation

### In Kodi (v21.0+ Omega):

1. **Settings** → **File Manager** → **Add Source**
2. Enter URL: `https://raw.githubusercontent.com/Akahwaj/sentinel-build/main/`
3. Name: `sentinel-build`
4. Click **OK**

5. **Add-ons** → **Install from Zip File**
6. Select `sentinel-build` → `repository.sentinel.build-1.0.0.zip`

7. **Add-ons** → **Install from Repository**
8. Select **SENTINEL Build Repository**
9. Choose **Program Add-ons** → **SENTINEL Wizard**
10. Click **Install**

11. Launch **SENTINEL Wizard** and choose your profile:
    - **Lite** (Fire Stick Lite/2nd Gen)
    - **Pro** (Fire Stick 4K / Android TV)
    - **Max** (Nvidia Shield / High-end)
    - **Safe** (Legal add-ons only, no debrid/VPN needed)

---

## ⚙️ Recommended Setup

### Debrid Services (Optional but Recommended)
- **Real-Debrid**: https://real-debrid.com
- **TorBox**: https://torbox.app
- **AllDebrid**: https://alldebrid.com
- **Premiumize**: https://www.premiumize.me

### VPN (For Torrent Add-ons)
- ExpressVPN
- NordVPN
- Surfshark
- IPVanish

---

## 📋 File Structure

```
sentinel-build/
├── LICENSE                          (GPL-3.0)
├── README.md                        (This file)
├── index.html                       (Web landing page)
├── addons.xml                       (Complete addon manifest)
├── addons.xml.md5                   (Integrity checksum)
├── repository.sentinel.build/
│   └── addon.xml                    (Repository definition)
└── plugin.sentinel.wizard/
    └── addon.xml                    (Wizard definition)
```

---

## 🔧 Profiles Explained

### SENTINEL Lite
**For:** Fire Stick Lite, Fire Stick 2nd Gen
**Includes:** 8 add-ons (Debrid focused)
**Requirements:** Debrid service (Real-Debrid recommended)

### SENTINEL Pro
**For:** Fire Stick 4K, Android TV, mid-range devices
**Includes:** 14 add-ons (All debrid + top free)
**Requirements:** Debrid service, some free add-ons work standalone

### SENTINEL Max
**For:** Nvidia Shield, high-end Android TV, tablets
**Includes:** All 18 add-ons
**Requirements:** Debrid + VPN (for torrent add-ons)

### SENTINEL Safe
**For:** Legal-only streaming, no debrid/VPN
**Includes:** 5 carefully selected legal add-ons
**Requirements:** None - works completely free and legal

---

## 🛠️ Troubleshooting

### "Unable to Connect"
- Check your device has internet access
- Try a different WiFi network
- Disable VPN temporarily to test
- Check if GitHub is blocked in your region

### "Invalid ZIP File"
- Make sure you're downloading the correct ZIP
- Clear Kodi cache: Settings → System → Cache
- Reinstall the repository

### Add-ons Not Installing
- Enable **Unknown Sources**: Settings → System → Add-ons
- Check each add-on's source repository is accessible
- Some add-ons require debrid account to function

### Slow Performance
- Use **SENTINEL Lite** profile for older devices
- Reduce Kodi library size
- Clear cache regularly
- Consider upgrading RAM/storage

---

## 📞 Support

### Before Asking for Help
1. Check your internet connection
2. Make sure you're on Kodi 21.0 or newer
3. Try clearing cache and cookies
4. Verify all sources are accessible

### Common Issues
- **Blank add-ons**: Sign into debrid account
- **Buffering**: Upgrade to faster debrid service
- **No links found**: Add-ons may be down temporarily
- **Installation errors**: Disable VPN, retry

---

## 📝 License

This repository is licensed under **GPL-3.0**. All third-party add-ons retain their original licenses.

---

## 🌐 Links

- **GitHub**: https://github.com/Akahwaj/sentinel-build
- **Repository URL**: https://raw.githubusercontent.com/Akahwaj/sentinel-build/main/

---

**SENTINEL BUILD - Professional Kodi Made Simple** ✅
