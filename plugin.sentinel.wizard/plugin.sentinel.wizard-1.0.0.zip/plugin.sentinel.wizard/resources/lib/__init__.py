"""SENTINEL Wizard support package."""
